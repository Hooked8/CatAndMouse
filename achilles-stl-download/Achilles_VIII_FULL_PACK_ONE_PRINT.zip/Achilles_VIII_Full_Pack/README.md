# Achilles VIII + QR — Bambu Lab P1S

Dual-color desk plaque with scannable QR + seating stand.

- **QR URL:** https://cjz63c-nh.myshopify.com
- **Plaque size:** 83.8 × 172.0 × 2.8 mm
- **QR module:** 1.8 mm (Version 4, quiet zone included)

## STLs (import into Bambu Studio)

| File | Color |
|------|-------|
| `achilles_qr_base_BLACK.stl` | **Black** matte PLA |
| `achilles_qr_accent_WHITE.stl` | **White** or silver PLA |
| `desk_stand_SEATING.stl` | Black (or any) |

`achilles_qr_COMBINED_preview.stl` = single-file preview only.

## Print settings
1. Printer: **Bambu Lab P1S**, 0.4 mm nozzle  
2. Layer height: **0.20 mm**  
3. Import base + accent together (aligned coordinates)  
4. Assign AMS extruders: base→black, accent→white  
5. Orientation: **flat on PEI, accent face UP**  
6. No supports · ~15% infill · matte filaments scan best  

## Why the QR works
Black modules are **holes** in the white accent so the black base shows through flush — high contrast, phone-scannable.

## Seating
Print `desk_stand_SEATING.stl` and slide the plaque into the slot.

## Previews
See the `preview/` folder.
