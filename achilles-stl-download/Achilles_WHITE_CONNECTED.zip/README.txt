Achilles WHITE connected — logo is on a solid underplate so the whole white accent peels as ONE piece.
Import WHITE + BLACK together for dual color.
