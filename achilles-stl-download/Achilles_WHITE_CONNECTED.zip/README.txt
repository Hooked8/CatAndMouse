Connected white — logo bonded to solid plate, peels as one piece.
