Connected white accent. Logo is on a solid plate — peels as ONE piece.
Print with black base STL for dual color.
